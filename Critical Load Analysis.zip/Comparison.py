import tkinter as tk
from tkinter import ttk, messagebox
import csv
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np
from pathlib import Path

CSV_FILE = Path("results.csv")

class EngineeringApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Structural Stability Dashboard")
        self.root.geometry("1000x650")
        
        # Header
        header = tk.Frame(root, bg="black", pady=15)
        header.pack(fill="x")
        
        tk.Label(header, text="COLUMN STABILITY ANALYSIS RESULTS", 
                 font=(None, 18, "bold"), fg="white", bg="black").pack()
        tk.Label(header, text="C++ Calculation + Python Visualization", 
                 font=(None, 10), fg="white", bg="black").pack()

        # Table
        table_frame = tk.Frame(root, pady=10, padx=10)
        table_frame.pack(fill="both", expand=True)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side="right", fill="y")
        
        # Treeview
        cols = ("Material", "Load", "Mode", "Slenderness")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", 
                                 height=15, yscrollcommand=scrollbar.set)
        
        # Define Columns
        self.tree.heading("Material", text="Material Name")
        self.tree.column("Material", width=200, anchor="w")
        
        self.tree.heading("Load", text="Critical Load (kN)")
        self.tree.column("Load", width=120, anchor="center")
        
        self.tree.heading("Mode", text="Failure Mode")
        self.tree.column("Mode", width=150, anchor="center")
        
        self.tree.heading("Slenderness", text="Slenderness Ratio")
        self.tree.column("Slenderness", width=120, anchor="center")
        
        self.tree.pack(fill="both", expand=True)
        scrollbar.config(command=self.tree.yview)

        # Buttons
        btn_frame = tk.Frame(root, pady=20, bg="white")
        btn_frame.pack(fill="x", side="bottom")
        
        # Load Button
        btn_load = tk.Button(btn_frame, text="Load Data", 
                             bg="green", fg="white",
                             command=self.load_data, width=25, relief="flat", pady=5)
        btn_load.pack(side="left", padx=50, pady=10)
        
        # Graph Button
        btn_graph = tk.Button(btn_frame, text="Show Graph", 
                              bg="green", fg="white",
                              command=self.show_graph, width=25, relief="flat", pady=5)
        btn_graph.pack(side="right", padx=50, pady=10)

    def load_data(self):
        # Clear existing data
        for row in self.tree.get_children():
            self.tree.delete(row)
            
        try:
            with open(CSV_FILE, 'r') as f:
                reader = csv.reader(f)
                header = next(reader, None)
                
                count = 0
                for row in reader:
                    if row: 
                        self.tree.insert("", "end", values=row)
                        count += 1
                        
            if count == 0:
                messagebox.showwarning("Empty File", "The results.csv file is empty!")
            else:
                messagebox.showinfo("Success", f"Successfully loaded {count} materials.")
                
        except FileNotFoundError:
            messagebox.showerror("File Error", 
                                 f"Could not find CSV file. Please check path directory in C++.")

    def show_graph(self):
        materials = []
        loads = []
        
        # Extracting data
        for child in self.tree.get_children():
            row = self.tree.item(child)['values']
            materials.append(row[0])
            loads.append(float(row[1]))
            
        if not materials:
            messagebox.showwarning("Warning", "Please load data.")
            return

        # Figure setup
        fig, ax = plt.subplots(figsize=(16, 9))
        
        # Material Color differentiation
        colors = cm.tab20(np.linspace(0, 1, len(materials)))
        
        # Horizontal Bars
        bars = ax.barh(materials, loads, color=colors, edgecolor='black', height=0.6)
        
        # Chart Formatting
        ax.set_xlabel("Critical Buckling Load (kN)", fontsize=12, fontweight='bold')
        ax.set_ylabel("Material Name", fontsize=12, fontweight='bold')
        ax.set_title(f"Comparative Strength Analysis ({len(materials)} Materials)", fontsize=16, pad=20)
        ax.grid(axis='x', linestyle='--', alpha=0.5)
        
        # Inverting Y axis so the first material in the list is at the top
        ax.invert_yaxis()
        
        # Labeling values of each bars
        max_load = max(loads)
        for bar in bars:
            width = bar.get_width()
            ax.text(width + (max_load * 0.01),        # X position
                    bar.get_y() + bar.get_height()/2, # Y position 
                    f'{width:.1f} kN',                # Text
                    va='center', fontsize=9, fontweight='bold', color='red')

        # Adding legend
        ax.legend(bars, materials, title="Material Key", 
                  loc='upper left', bbox_to_anchor=(1, 1), fontsize=9)
        
        plt.tight_layout()
        plt.show()


# Run application
if __name__ == "__main__":
    root = tk.Tk()
    app = EngineeringApp(root)
    root.mainloop()
